package sistema;

import produccion.CadenaMontaje;
import vehiculos.Vehiculo;

public class DashboardImpl implements Dashboard {

    private FactoryController controller;

    public DashboardImpl(FactoryController controller) {
        this.controller = controller;
    }

    @Override
    public void mostrar() {

        System.out.println("===== DASHBOARD =====");

        // Mostrar estado de la cadena
        CadenaMontaje c = controller.getPrimeraCadena();

        if (c != null) {
            System.out.println("Vehículos en cola:");

            for (Vehiculo v : c.getCola()) {
                System.out.println(v);
            }
        } else {
            System.out.println("No hay cadenas");
        }

        // Mostrar stock
        System.out.println("\nStock de motores gasolina: " +
                controller.getAlmacen().getStockMotor(componentes.TipoMotor.GASOLINA));

        System.out.println("=====================");
    }
}