package produccion;


/**
 * Write a description of class SchedulerComplejo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SchedulerComplejo implements Scheduler {

    @Override
    public void avanzarTiempo(int segundos) {

    }
}