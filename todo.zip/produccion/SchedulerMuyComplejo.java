package produccion;


/**
 * Write a description of class SchedulerMuyComplejo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SchedulerMuyComplejo implements Scheduler {
    @Override
    public void avanzarTiempo(int segundos) {

    }
}