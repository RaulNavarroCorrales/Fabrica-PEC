package produccion;

public class SchedulerSimple implements Scheduler {

    private CadenaMontaje cadena;

    public SchedulerSimple(CadenaMontaje cadena) {
        this.cadena = cadena;
    }

    @Override
    public void avanzarTiempo(int segundos) {
        for (int i = 0; i < segundos; i++) {
            if (cadena.verPrimero() == null) {
                System.out.println("Simulación terminada (no hay mas vehículos en la cola)");
                break;
            }
            System.out.println("Segundo " + (i + 1));
            cadena.avanzar();
        }
    }
}